/** @format */

window.open("index.html");
