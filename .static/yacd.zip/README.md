# Yacd-Crx

![image](https://user-images.githubusercontent.com/64564727/230089264-175a05cd-824f-472f-a936-bd2ce38a6e6c.png)

**自动将 Yacd 仪表盘打包成 Chrome 拓展程序以便离线使用。**

- 在 [此处](https://github.com/huangyinhaow/yacd-crx/releases/download/auto/yacd.crx) 下载适用于 Clash 的最新 `.crx` 文件。
- 在 [此处](https://github.com/huangyinhaow/yacd-crx/releases/download/auto/yacd-meta.crx) 下载适用于 Clash.Meta 的最新 `.crx` 文件。

当前，你只可以同时安装其中的一个。
